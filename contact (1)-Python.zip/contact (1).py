import os
def add():
    os.system('cls')
    f = open("contact.csv", "a")
    print("\n\nADD CONTACT:")
    print("------------\n\n")
    name = input("Enter Name:")
    name=name.upper()
    num = (input("Enter Number:"))
    while(len(num)!=10):
        num=input("\nInvalid number!!\nEnter valid number:")
    email = input("Enter Email:")
    while("@" not in email):
        email=input("Invalid email!!\nEnter valid email id:")
    
    str = name + "," + num + "," + email + "\n"
    f.write(str)
    f.close()

def search():
    os.system('cls')
    f = open("contact.csv", "r")
    print("\n\nSEARCH CONTACT:")
    print("---------------\n\n")
    flag=0
    numbers=f.readlines()
    Name=input("Enter Name for Search:")
    Name=Name.upper()
    for number in numbers:
        name=number[0:number.index(",")]
        num=number[number.index(",")+1:number.index(",")+11]
        email=number[number.index(",")+12:]
        print()
        if Name==name:
            print("Name:",name)
            print("Mobile no:",num)
            print("Email:",email)
            flag+=1
            print("---------------------------")

    if flag==0:
        print("Data not found!!")
        input("press any key to continue:")

    else:
        print(flag,"Data found Successfully!!")
        input("press any key to continue:")
    f.close()
            

def display():
    os.system('cls')
    f = open("contact.csv", "r")
    flag=0
    print("\n\nDISPLAY CONTACTS:")
    print("-----------------\n\n")
    numbers=f.readlines()
    for number in numbers:
        name=number[0:number.index(",")]
        num=number[number.index(",")+1:number.index(",")+11]
        email=number[number.index(",")+12:]
        print("Name:",name)
        print("Mobile no:",num)
        print("Email:",email)
        flag+=1
        print("---------------------------\n")
    print("Total Contacts:",flag,"!!")

    input("press any key to continue:")
    f.close()

def delete():
    f = open("contact.csv","r+")
    os.system('cls')
    flag=0
    print("\n\nDELETE CONTACTS:")
    print("-----------------\n\n")
    numbers=f.readlines()
    NAME=input("Enter Name to delete the number:")
    NAME=NAME.upper()
    f.close()
    f = open("contact.csv","w+")
    l=f.readlines()
    f = open("contact.csv","a+")
    for number in numbers:
        name=number[0:number.index(",")]
        num=number[number.index(",")+1:number.index(",")+11]
        email=number[number.index(",")+12:]
        str = name+","+num+','+email
        if NAME==name:
            print("Name:",name)
            print("Mobile no:",num)
            print("Email:",email)
            print("---------------------------\n")
            flag+=1
        else:
            f.write(str)
    print("Total",flag,"CONTACT DELETED!!")
    input("press any key to continue:")
    f.close()


while(1):
    print("\n\n*************WELCOME TO CONTACT MANAGER*************")
    print("----------------------------------------------------\n\n")
    print("1)Add Contact")
    print("2)Delete Contact")
    print("3)Search Contact")
    print("4)Display Contact")
    print("5)Exit\n")
    c = int(input("Enter your choice:"))

    if c==1:
         add()
         

    elif c==2:
         delete()

    elif c==3:
         search()

    elif c==4:
         display()

    elif c==5:
         
         input("press any key")
         exit()
    os.system('cls')

        
